package com.bib.tp7_ex2;


import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private TextView tvX;
    private TextView tvY;
    private TextView tvZ;
    private Button btnAjouter;
    private Button btnVider;
    private EditText edList;
    private SensorManager mg;
    private Sensor accelerometer;
    private String a="m/s²";
   

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        tvX = (TextView) findViewById(R.id.tvX);
        tvY = (TextView) findViewById(R.id.tvY);
        tvZ = (TextView) findViewById(R.id.tvZ);
        btnAjouter = (Button) findViewById(R.id.btnAjouter);
        btnVider = (Button) findViewById(R.id.btnVider);
        edList = (EditText) findViewById(R.id.edList);
        mg=(SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = mg.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        ajouterEcouteurs();
    }

    private void ajouterEcouteurs() {
        btnAjouter.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                ajouter();

            }
        });
        btnVider.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                vider();

            }
        });

    }

    protected void vider() {
        edList.setText("");

    }

    protected void ajouter() {
       edList.setText("("+tvX.getText().toString()+","+tvY.getText().toString()+","+tvZ.getText().toString()+")");


    }

    @Override
    protected void onPause() {
        mg.unregisterListener(this,accelerometer);
    super.onPause();

    }

    @Override
    protected void onResume() {
        mg.registerListener(this,accelerometer,SensorManager.SENSOR_DELAY_UI);
        super.onResume();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float x, y, z;
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            x = event.values[0];
            y = event.values[1];
            z = event.values[2];

            tvX.setText(x + "m/s²");
            tvY.setText(y + "m/s²");
            tvZ.setText(z + "m/s²");
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}

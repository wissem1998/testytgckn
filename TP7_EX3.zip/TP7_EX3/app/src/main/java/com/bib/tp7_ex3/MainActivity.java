package com.bib.tp7_ex3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    public static final int[] TAB_PRES = new int[]{R.drawable.pres00,R.drawable.pres01,R.drawable.pres02,R.drawable.pres03};
    public static final int[] TAB_LOIN = new int[]{R.drawable.loin00,R.drawable.loin01,R.drawable.loin02,R.drawable.loin03};
    private TextView tvProx;
    private ImageView imgPL;
    private SensorManager mg;
    private Sensor accelerer;
    private Sensor aproximer;
    private int indice;
    private static final int NORME=11;
   

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        tvProx=findViewById(R.id.tvProx);
        imgPL = findViewById(R.id.imgPL);
        mg=(SensorManager) getSystemService(SENSOR_SERVICE);
        accelerer = mg.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        aproximer = mg.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        indice = 0;
        ajouterEcouteur();
    }

    private void ajouterEcouteur() {

    }

    @Override
    protected void onPause() {
        mg.unregisterListener(this,accelerer);
        mg.unregisterListener(this,aproximer);
        super.onPause();
    }

    @Override
    protected void onResume() {
        mg.registerListener(this,accelerer,SensorManager.SENSOR_DELAY_UI);
        mg.registerListener(this,aproximer,SensorManager.SENSOR_DELAY_UI);
        super.onResume();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float x, y, z,prox;
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            x = event.values[0];
            y = event.values[1];
            z = event.values[2];
            double norme=Math.sqrt(Math.pow(x,2)+Math.pow(y,2)+Math.pow(z,2));
            if(norme>NORME)
                Suivant();
        }
        else if(event.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            prox=event.values[0];
            tvProx.setText(prox+"");
            if(prox==0)
                imgPL.setImageResource(TAB_PRES[indice]);
            else
                imgPL.setImageResource(TAB_LOIN[indice]);
        }
    }

    private void Suivant() {
        indice=(indice+1)%TAB_PRES.length;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}

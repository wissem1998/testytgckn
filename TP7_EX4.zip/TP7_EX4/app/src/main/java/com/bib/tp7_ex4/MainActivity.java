package com.bib.tp7_ex4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.Switch;


public class MainActivity extends AppCompatActivity implements SensorEventListener {
    public static final double NORME_MODIF = 15;
    private Switch swOnOff;
    //flag to detect flash is on or off
    private Camera camera;
    Camera.Parameters p;
    private boolean isLighOn;
    private SensorManager mg;
    private Sensor accelerer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initGraphique();
        initCamera();
    }

    private void initGraphique() {
        swOnOff = findViewById(R.id.swOnOff);
        mg=(SensorManager) getSystemService(SENSOR_SERVICE);
        accelerer = mg.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        ajouterEcouteurs();


    }

    private void ajouterEcouteurs() {
        swOnOff.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                onOff(isChecked);
            }
        });
    }

    private void onOff(boolean isChecked) {
        if (isChecked) {
            Log.i("info", "torch is turn on!");

            p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);

            camera.setParameters(p);
            camera.startPreview();
            isLighOn = true;


        } else {
            Log.i("info", "torch is turn off!");

            p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
            camera.setParameters(p);
            camera.stopPreview();
            isLighOn = false;


        }
    }

    private void initCamera() {


        Context context = this;
        PackageManager pm = context.getPackageManager();
        isLighOn = false;

        // if device support camera?
        if (!pm.hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
            Log.e("err", "Device has no camera!");
            return;
        }

        camera = Camera.open();
        p = camera.getParameters();


    }

    private void releaseCamera() {
        if (camera != null) {
            onOff(false);
            camera.release();
        }
    }

    @Override
    protected void onDestroy() {
        releaseCamera();
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        mg.unregisterListener(this,accelerer);
        super.onPause();
    }

    @Override
    protected void onResume() {
        mg.registerListener(this,accelerer,SensorManager.SENSOR_DELAY_UI);
        super.onResume();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}